﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class NavGraph 
{
    public List<GraphNode> Nodes = new List<GraphNode>();
}
